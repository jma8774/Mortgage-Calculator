# Mortgage-Calculator
(4/2019) Mortgage calculator made using JavaFx
